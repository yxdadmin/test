package com.example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Demo3ApplicationTests {

	@Test
	public void contextLoads() {
	}

}
