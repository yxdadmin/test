package com.example.dao;

import com.example.domain.User;
import org.springframework.stereotype.Repository;

/**
 * @Description
 * @Author 杨希栋
 * @Date 2017/3/8 16:13
 */
@Repository
public interface UserDao {

    public int addUser(User user);
}
