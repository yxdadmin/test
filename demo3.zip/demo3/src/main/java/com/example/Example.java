package com.example;

import com.example.domain.User;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Description
 * @Author 杨希栋
 * @Date 2017/3/8 13:22
 */
@Controller
@EnableAutoConfiguration
public class Example {


    @RequestMapping("/aa")
    public String doSave(){
        User user = new User();
        user.setUserName("张三");
        user.setAge(23);
        return "index";
    }
}
