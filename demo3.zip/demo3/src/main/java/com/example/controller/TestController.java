package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Map;

/**
 * @Description
 * @Author 杨希栋
 * @Date 2017/3/9 10:09
 */
@Controller
public class TestController {

    @RequestMapping("/doTest")
    public String doTest(Model model){
        model.addAttribute("time",new Date());
        model.addAttribute("desc","错误的描述");
        return "index";
    }
}
