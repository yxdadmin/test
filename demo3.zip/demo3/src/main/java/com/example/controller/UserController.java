package com.example.controller;

import com.example.domain.User;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description
 * @Author 杨希栋
 * @Date 2017/3/8 16:18
 */
@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/doindex")
    public String doindex(Model model){
        User user = new User();
        user.setAge(22);
        user.setUserName("234332");
        int aa = userService.addUser(user);
        model.addAttribute("aa",aa);
        model.addAttribute("user",user);
        return "index";

    }
}
