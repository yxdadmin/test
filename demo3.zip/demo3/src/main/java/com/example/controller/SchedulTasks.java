package com.example.controller;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @Description
 * @Author 杨希栋
 * @Date 2017/3/9 13:49
 */
@Component
public class SchedulTasks {

    private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    //定时任务：单位：毫秒；
    //设定没两分钟执行一次
    @Scheduled(fixedRate = 60000*2)
    public void queryOrder(){
        Calendar calendar = Calendar.getInstance();
        //当前时间
        Date date = new Date();
        String dnow = sdf.format(date);
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH,-1);
        //前一天时间
        String dbfore = sdf.format(calendar.getTime());

        System.out.println("前一天时间:" + dbfore + ",当前时间" + dnow);

    }
}
